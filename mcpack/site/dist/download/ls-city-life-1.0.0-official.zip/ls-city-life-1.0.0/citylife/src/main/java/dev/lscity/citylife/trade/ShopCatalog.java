package dev.lscity.citylife.trade;

import dev.lscity.citylife.trade.Shop.ShopItem;
import dev.lscity.citylife.trade.Shop.ShopOffer;

import java.util.List;
import java.util.Map;

/**
 * Ассортимент прилавков.
 *
 * Файл собран скриптом citylife/tools/gen_shops.py из того же списка,
 * по которому расставляются NPC, — править руками не нужно.
 */
public final class ShopCatalog {

    public static final Map<String, Shop> BY_ROLE = Map.ofEntries(
            Map.entry("ammo_seller", new Shop("Патроны", List.of(
                    new ShopOffer(new ShopItem("citylife:banknote_100", 6, null), new ShopItem("tacz:ammo", 30, "{AmmoId:\"elitex:dmr_rifles_ammo\"}")),
                    new ShopOffer(new ShopItem("citylife:banknote_100", 3, null), new ShopItem("tacz:ammo", 30, "{AmmoId:\"elitex:five_seven_ammo\"}")),
                    new ShopOffer(new ShopItem("citylife:banknote_100", 6, null), new ShopItem("tacz:ammo", 30, "{AmmoId:\"elitex:kar98k_ammo\"}")),
                    new ShopOffer(new ShopItem("citylife:banknote_100", 6, null), new ShopItem("tacz:ammo", 30, "{AmmoId:\"elitex:rifles_ammo\"}")),
                    new ShopOffer(new ShopItem("citylife:banknote_100", 6, null), new ShopItem("tacz:ammo", 30, "{AmmoId:\"elitex:sig_fury_ammo\"}")),
                    new ShopOffer(new ShopItem("citylife:banknote_100", 18, null), new ShopItem("tacz:ammo", 30, "{AmmoId:\"elitex:sp_ammo\"}")),
                    new ShopOffer(new ShopItem("citylife:banknote_100", 18, null), new ShopItem("tacz:ammo", 30, "{AmmoId:\"elitex:trs_bull_ammo\"}")),
                    new ShopOffer(new ShopItem("citylife:banknote_100", 6, null), new ShopItem("tacz:ammo", 30, "{AmmoId:\"elitex:waffe_ammo\"}")),
                    new ShopOffer(new ShopItem("citylife:banknote_100", 8, null), new ShopItem("tacz:ammo", 30, "{AmmoId:\"tacz:12g\"}")),
                    new ShopOffer(new ShopItem("citylife:banknote_100", 3, null), new ShopItem("tacz:ammo", 30, "{AmmoId:\"tacz:22wmr\"}")),
                    new ShopOffer(new ShopItem("citylife:banknote_100", 6, null), new ShopItem("tacz:ammo", 30, "{AmmoId:\"tacz:308\"}")),
                    new ShopOffer(new ShopItem("citylife:banknote_100", 6, null), new ShopItem("tacz:ammo", 30, "{AmmoId:\"tacz:30_06\"}")),
                    new ShopOffer(new ShopItem("citylife:banknote_100", 18, null), new ShopItem("tacz:ammo", 30, "{AmmoId:\"tacz:338\"}")),
                    new ShopOffer(new ShopItem("citylife:banknote_100", 3, null), new ShopItem("tacz:ammo", 30, "{AmmoId:\"tacz:357mag\"}")),
                    new ShopOffer(new ShopItem("citylife:banknote_100", 8, null), new ShopItem("tacz:ammo", 1, "{AmmoId:\"tacz:40mm\"}")),
                    new ShopOffer(new ShopItem("citylife:banknote_100", 18, null), new ShopItem("tacz:ammo", 30, "{AmmoId:\"tacz:45_70\"}")),
                    new ShopOffer(new ShopItem("citylife:banknote_100", 3, null), new ShopItem("tacz:ammo", 30, "{AmmoId:\"tacz:45acp\"}")),
                    new ShopOffer(new ShopItem("citylife:banknote_100", 3, null), new ShopItem("tacz:ammo", 30, "{AmmoId:\"tacz:46x30\"}")),
                    new ShopOffer(new ShopItem("citylife:banknote_100", 3, null), new ShopItem("tacz:ammo", 30, "{AmmoId:\"tacz:500mag\"}")),
                    new ShopOffer(new ShopItem("citylife:banknote_100", 3, null), new ShopItem("tacz:ammo", 30, "{AmmoId:\"tacz:50ae\"}")),
                    new ShopOffer(new ShopItem("citylife:banknote_100", 18, null), new ShopItem("tacz:ammo", 30, "{AmmoId:\"tacz:50bmg\"}")),
                    new ShopOffer(new ShopItem("citylife:banknote_100", 6, null), new ShopItem("tacz:ammo", 30, "{AmmoId:\"tacz:545x39\"}")),
                    new ShopOffer(new ShopItem("citylife:banknote_100", 6, null), new ShopItem("tacz:ammo", 30, "{AmmoId:\"tacz:556x45\"}")),
                    new ShopOffer(new ShopItem("citylife:banknote_100", 3, null), new ShopItem("tacz:ammo", 30, "{AmmoId:\"tacz:57x28\"}")),
                    new ShopOffer(new ShopItem("citylife:banknote_100", 6, null), new ShopItem("tacz:ammo", 30, "{AmmoId:\"tacz:58x42\"}")),
                    new ShopOffer(new ShopItem("citylife:banknote_100", 6, null), new ShopItem("tacz:ammo", 30, "{AmmoId:\"tacz:68x51fury\"}")),
                    new ShopOffer(new ShopItem("citylife:banknote_100", 3, null), new ShopItem("tacz:ammo", 30, "{AmmoId:\"tacz:762x25\"}")),
                    new ShopOffer(new ShopItem("citylife:banknote_100", 6, null), new ShopItem("tacz:ammo", 30, "{AmmoId:\"tacz:762x39\"}")),
                    new ShopOffer(new ShopItem("citylife:banknote_100", 6, null), new ShopItem("tacz:ammo", 30, "{AmmoId:\"tacz:762x54\"}")),
                    new ShopOffer(new ShopItem("citylife:banknote_100", 6, null), new ShopItem("tacz:ammo", 30, "{AmmoId:\"tacz:792x57\"}")),
                    new ShopOffer(new ShopItem("citylife:banknote_100", 3, null), new ShopItem("tacz:ammo", 30, "{AmmoId:\"tacz:9mm\"}")),
                    new ShopOffer(new ShopItem("citylife:banknote_100", 25, null), new ShopItem("tacz:ammo", 1, "{AmmoId:\"tacz:rpg_rocket\"}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 1, null), new ShopItem("tacz:ammo_box", 1, "{Level:0}"))))),
            Map.entry("arms_dealer", new Shop("Пистолеты, ПП, дробовики", List.of(
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 6, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"elitex:bo1_1911\",GunFireMode:\"SEMI\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 6, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"elitex:colt_m1911x1\",GunFireMode:\"SEMI\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 6, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"elitex:five_seven\",GunFireMode:\"SEMI\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 6, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"elitex:jrx\",GunFireMode:\"SEMI\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 6, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"elitex:op1911\",GunFireMode:\"SEMI\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 6, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"elitex:springfield_m1911\",GunFireMode:\"SEMI\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 6, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"elitex:srz_2011\",GunFireMode:\"SEMI\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 6, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"elitex:trs_bull\",GunFireMode:\"SEMI\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 6, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"tacz:b93r\",GunFireMode:\"BURST\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 6, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"tacz:cz75\",GunFireMode:\"AUTO\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 6, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"tacz:deagle\",GunFireMode:\"SEMI\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 6, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"tacz:glock_17\",GunFireMode:\"SEMI\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 6, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"tacz:hk_mk23\",GunFireMode:\"SEMI\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 6, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"tacz:lonetrail\",GunFireMode:\"SEMI\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 6, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"tacz:m1911\",GunFireMode:\"SEMI\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 6, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"tacz:m9a4\",GunFireMode:\"SEMI\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 6, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"tacz:p320\",GunFireMode:\"SEMI\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 6, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"tacz:rhino357\",GunFireMode:\"SEMI\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 6, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"tacz:taurus500\",GunFireMode:\"SEMI\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 6, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"tacz:taurus943\",GunFireMode:\"SEMI\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 6, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"tacz:timeless50\",GunFireMode:\"SEMI\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_5000", 4, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"tacz:deagle_golden\",GunFireMode:\"SEMI\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 12, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"elitex:mp5_classic\",GunFireMode:\"AUTO\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 12, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"elitex:mp7r\",GunFireMode:\"AUTO\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 12, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"elitex:ro635v3\",GunFireMode:\"AUTO\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 12, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"elitex:vector45acp\",GunFireMode:\"AUTO\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 12, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"tacz:hk_mp5a5\",GunFireMode:\"AUTO\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 12, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"tacz:p90\",GunFireMode:\"AUTO\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 12, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"tacz:ump45\",GunFireMode:\"AUTO\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 12, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"tacz:uzi\",GunFireMode:\"AUTO\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 12, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"tacz:vector45\",GunFireMode:\"AUTO\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 12, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"elitex:benelli_super\",GunFireMode:\"SEMI\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 12, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"elitex:spaz12\",GunFireMode:\"BURST\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 12, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"tacz:aa12\",GunFireMode:\"SEMI\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 12, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"tacz:db_long\",GunFireMode:\"SEMI\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 12, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"tacz:db_short\",GunFireMode:\"BURST\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 12, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"tacz:m1014\",GunFireMode:\"SEMI\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 12, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"tacz:m870\",GunFireMode:\"SEMI\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 12, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"tacz:spas_12\",GunFireMode:\"SEMI\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}"))))),
            Map.entry("banker", new Shop("Городской банк", List.of(
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 2, null), new ShopItem("citylife:atm", 1, null)),
                    new ShopOffer(new ShopItem("citylife:banknote_100", 3, null), new ShopItem("minecraft:paper", 8, null)),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 1, null), new ShopItem("minecraft:iron_block", 2, null))))),
            Map.entry("bartender", new Shop("Бар", List.of(
                    new ShopOffer(new ShopItem("citylife:coin_10", 4, null), new ShopItem("minecraft:honey_bottle", 2, null)),
                    new ShopOffer(new ShopItem("citylife:banknote_100", 1, null), new ShopItem("minecraft:jukebox", 1, null)),
                    new ShopOffer(new ShopItem("citylife:coin_10", 6, null), new ShopItem("minecraft:music_disc_cat", 1, null))))),
            Map.entry("builder", new Shop("Стройка", List.of(
                    new ShopOffer(new ShopItem("citylife:coin_10", 5, null), new ShopItem("minecraft:scaffolding", 16, null)),
                    new ShopOffer(new ShopItem("citylife:banknote_100", 1, null), new ShopItem("minecraft:smooth_stone", 32, null))))),
            Map.entry("car_dealer", new Shop("Автосалон", List.of(
                    new ShopOffer(new ShopItem("citylife:banknote_100", 3, null), new ShopItem("vehicle:wrench", 1, null)),
                    new ShopOffer(new ShopItem("citylife:banknote_100", 2, null), new ShopItem("citylife:fuel_canister", 1, null)),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 4, null), new ShopItem("vehicle:vehicle_crate", 1, "{BlockEntityTag:{Vehicle:\"vehicle:moped\",Color:14696762,EngineStack:{id:\"vehicle:iron_small_engine\",Count:1b},WheelStack:{id:\"vehicle:standard_wheel\",Count:1b}},display:{Name:'{\"text\": \"Мопед — ящик\", \"italic\": false}',Lore:['{\"text\": \"Поставь и ударь сверху гаечным ключом\", \"color\": \"gray\", \"italic\": false}']}}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 3, null), new ShopItem("vehicle:vehicle_crate", 1, "{BlockEntityTag:{Vehicle:\"vehicle:mini_bike\",Color:3112928,EngineStack:{id:\"vehicle:iron_small_engine\",Count:1b},WheelStack:{id:\"vehicle:standard_wheel\",Count:1b}},display:{Name:'{\"text\": \"Минибайк — ящик\", \"italic\": false}',Lore:['{\"text\": \"Поставь и ударь сверху гаечным ключом\", \"color\": \"gray\", \"italic\": false}']}}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 9, null), new ShopItem("vehicle:vehicle_crate", 1, "{BlockEntityTag:{Vehicle:\"vehicle:dirt_bike\",Color:15764004,EngineStack:{id:\"vehicle:gold_small_engine\",Count:1b},WheelStack:{id:\"vehicle:off_road_wheel\",Count:1b}},display:{Name:'{\"text\": \"Мотокросс — ящик\", \"italic\": false}',Lore:['{\"text\": \"Поставь и ударь сверху гаечным ключом\", \"color\": \"gray\", \"italic\": false}']}}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 12, null), new ShopItem("vehicle:vehicle_crate", 1, "{BlockEntityTag:{Vehicle:\"vehicle:quad_bike\",Color:4099649,EngineStack:{id:\"vehicle:gold_small_engine\",Count:1b},WheelStack:{id:\"vehicle:off_road_wheel\",Count:1b}},display:{Name:'{\"text\": \"Квадроцикл — ящик\", \"italic\": false}',Lore:['{\"text\": \"Поставь и ударь сверху гаечным ключом\", \"color\": \"gray\", \"italic\": false}']}}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 14, null), new ShopItem("vehicle:vehicle_crate", 1, "{BlockEntityTag:{Vehicle:\"vehicle:atv\",Color:9202238,EngineStack:{id:\"vehicle:gold_small_engine\",Count:1b},WheelStack:{id:\"vehicle:all_terrain_wheel\",Count:1b}},display:{Name:'{\"text\": \"Вездеход ATV — ящик\", \"italic\": false}',Lore:['{\"text\": \"Поставь и ударь сверху гаечным ключом\", \"color\": \"gray\", \"italic\": false}']}}")),
                    new ShopOffer(new ShopItem("citylife:banknote_5000", 2, null), new ShopItem("vehicle:vehicle_crate", 1, "{BlockEntityTag:{Vehicle:\"vehicle:go_kart\",Color:15909166,EngineStack:{id:\"vehicle:diamond_small_engine\",Count:1b},WheelStack:{id:\"vehicle:racing_wheel\",Count:1b}},display:{Name:'{\"text\": \"Картинг — ящик\", \"italic\": false}',Lore:['{\"text\": \"Поставь и ударь сверху гаечным ключом\", \"color\": \"gray\", \"italic\": false}']}}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 8, null), new ShopItem("vehicle:vehicle_crate", 1, "{BlockEntityTag:{Vehicle:\"vehicle:golf_cart\",Color:16053492,EngineStack:{id:\"vehicle:iron_electric_engine\",Count:1b},WheelStack:{id:\"vehicle:standard_wheel\",Count:1b}},display:{Name:'{\"text\": \"Гольф-кар — ящик\", \"italic\": false}',Lore:['{\"text\": \"Поставь и ударь сверху гаечным ключом\", \"color\": \"gray\", \"italic\": false}']}}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 18, null), new ShopItem("vehicle:vehicle_crate", 1, "{BlockEntityTag:{Vehicle:\"vehicle:smart_car\",Color:3054550,EngineStack:{id:\"vehicle:gold_electric_engine\",Count:1b},WheelStack:{id:\"vehicle:standard_wheel\",Count:1b}},display:{Name:'{\"text\": \"Смарт-кар — ящик\", \"italic\": false}',Lore:['{\"text\": \"Поставь и ударь сверху гаечным ключом\", \"color\": \"gray\", \"italic\": false}']}}")),
                    new ShopOffer(new ShopItem("citylife:banknote_5000", 3, null), new ShopItem("vehicle:vehicle_crate", 1, "{BlockEntityTag:{Vehicle:\"vehicle:dune_buggy\",Color:15253850,EngineStack:{id:\"vehicle:gold_small_engine\",Count:1b},WheelStack:{id:\"vehicle:off_road_wheel\",Count:1b}},display:{Name:'{\"text\": \"Багги — ящик\", \"italic\": false}',Lore:['{\"text\": \"Поставь и ударь сверху гаечным ключом\", \"color\": \"gray\", \"italic\": false}']}}")),
                    new ShopOffer(new ShopItem("citylife:banknote_5000", 7, null), new ShopItem("vehicle:vehicle_crate", 1, "{BlockEntityTag:{Vehicle:\"vehicle:off_roader\",Color:1973796,EngineStack:{id:\"vehicle:gold_large_engine\",Count:1b},WheelStack:{id:\"vehicle:off_road_wheel\",Count:1b}},display:{Name:'{\"text\": \"Внедорожник — ящик\", \"italic\": false}',Lore:['{\"text\": \"Поставь и ударь сверху гаечным ключом\", \"color\": \"gray\", \"italic\": false}']}}")),
                    new ShopOffer(new ShopItem("citylife:banknote_5000", 9, null), new ShopItem("vehicle:vehicle_crate", 1, "{BlockEntityTag:{Vehicle:\"vehicle:mini_bus\",Color:14277084,EngineStack:{id:\"vehicle:iron_large_engine\",Count:1b},WheelStack:{id:\"vehicle:standard_wheel\",Count:1b}},display:{Name:'{\"text\": \"Микроавтобус — ящик\", \"italic\": false}',Lore:['{\"text\": \"Поставь и ударь сверху гаечным ключом\", \"color\": \"gray\", \"italic\": false}']}}")),
                    new ShopOffer(new ShopItem("citylife:banknote_5000", 4, null), new ShopItem("vehicle:vehicle_crate", 1, "{BlockEntityTag:{Vehicle:\"vehicle:tractor\",Color:4168506,EngineStack:{id:\"vehicle:iron_large_engine\",Count:1b},WheelStack:{id:\"vehicle:off_road_wheel\",Count:1b}},display:{Name:'{\"text\": \"Трактор — ящик\", \"italic\": false}',Lore:['{\"text\": \"Поставь и ударь сверху гаечным ключом\", \"color\": \"gray\", \"italic\": false}']}}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 6, null), new ShopItem("vehicle:vehicle_crate", 1, "{BlockEntityTag:{Vehicle:\"vehicle:aluminum_boat\",Color:12108492,EngineStack:{id:\"vehicle:iron_small_engine\",Count:1b}},display:{Name:'{\"text\": \"Лодка — ящик\", \"italic\": false}',Lore:['{\"text\": \"Поставь и ударь сверху гаечным ключом\", \"color\": \"gray\", \"italic\": false}']}}")),
                    new ShopOffer(new ShopItem("citylife:banknote_5000", 3, null), new ShopItem("vehicle:vehicle_crate", 1, "{BlockEntityTag:{Vehicle:\"vehicle:jet_ski\",Color:14826346,EngineStack:{id:\"vehicle:gold_small_engine\",Count:1b}},display:{Name:'{\"text\": \"Гидроцикл — ящик\", \"italic\": false}',Lore:['{\"text\": \"Поставь и ударь сверху гаечным ключом\", \"color\": \"gray\", \"italic\": false}']}}")),
                    new ShopOffer(new ShopItem("citylife:banknote_5000", 6, null), new ShopItem("vehicle:vehicle_crate", 1, "{BlockEntityTag:{Vehicle:\"vehicle:speed_boat\",Color:16777215,EngineStack:{id:\"vehicle:gold_large_engine\",Count:1b}},display:{Name:'{\"text\": \"Катер — ящик\", \"italic\": false}',Lore:['{\"text\": \"Поставь и ударь сверху гаечным ключом\", \"color\": \"gray\", \"italic\": false}']}}")),
                    new ShopOffer(new ShopItem("citylife:banknote_5000", 24, null), new ShopItem("vehicle:vehicle_crate", 1, "{BlockEntityTag:{Vehicle:\"vehicle:compact_helicopter\",Color:2830138,EngineStack:{id:\"vehicle:diamond_small_engine\",Count:1b}},display:{Name:'{\"text\": \"Вертолёт — ящик\", \"italic\": false}',Lore:['{\"text\": \"Поставь и ударь сверху гаечным ключом\", \"color\": \"gray\", \"italic\": false}']}}")),
                    new ShopOffer(new ShopItem("citylife:banknote_5000", 30, null), new ShopItem("vehicle:vehicle_crate", 1, "{BlockEntityTag:{Vehicle:\"vehicle:sports_plane\",Color:12597547,EngineStack:{id:\"vehicle:diamond_large_engine\",Count:1b}},display:{Name:'{\"text\": \"Самолёт — ящик\", \"italic\": false}',Lore:['{\"text\": \"Поставь и ударь сверху гаечным ключом\", \"color\": \"gray\", \"italic\": false}']}}"))))),
            Map.entry("clerk", new Shop("Мэрия", List.of(
                    new ShopOffer(new ShopItem("citylife:coin_10", 4, null), new ShopItem("minecraft:paper", 8, null)),
                    new ShopOffer(new ShopItem("citylife:banknote_100", 1, null), new ShopItem("minecraft:map", 1, null)),
                    new ShopOffer(new ShopItem("citylife:banknote_100", 2, null), new ShopItem("minecraft:compass", 1, null))))),
            Map.entry("cook", new Shop("Закусочная", List.of(
                    new ShopOffer(new ShopItem("citylife:coin_10", 4, null), new ShopItem("minecraft:cooked_chicken", 3, null)),
                    new ShopOffer(new ShopItem("citylife:coin_10", 5, null), new ShopItem("minecraft:pumpkin_pie", 2, null)),
                    new ShopOffer(new ShopItem("citylife:coin_10", 3, null), new ShopItem("minecraft:cake", 1, null))))),
            Map.entry("cop", new Shop("Магазин", List.of(
))),
            Map.entry("firefighter", new Shop("Магазин", List.of(
))),
            Map.entry("foreman", new Shop("Прораб", List.of(
                    new ShopOffer(new ShopItem("citylife:coin_10", 6, null), new ShopItem("minecraft:stone", 32, null)),
                    new ShopOffer(new ShopItem("citylife:banknote_100", 1, null), new ShopItem("minecraft:iron_ingot", 3, null))))),
            Map.entry("fuel_seller", new Shop("Заправка", List.of(
                    new ShopOffer(new ShopItem("citylife:coin_10", 15, null), new ShopItem("citylife:fuel_canister", 1, null)),
                    new ShopOffer(new ShopItem("citylife:banknote_100", 6, null), new ShopItem("citylife:fuel_canister", 5, null)),
                    new ShopOffer(new ShopItem("citylife:banknote_100", 3, null), new ShopItem("vehicle:wrench", 1, null)),
                    new ShopOffer(new ShopItem("citylife:coin_10", 3, null), new ShopItem("minecraft:cooked_beef", 4, null))))),
            Map.entry("gunsmith", new Shop("Мастерская оружейника", List.of(
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 3, null), new ShopItem("tacz:gun_smith_table", 1, null)),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 3, null), new ShopItem("tacz:workbench_a", 1, "{BlockId:\"tacz:ammo_workbench\"}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 3, null), new ShopItem("tacz:workbench_c", 1, "{BlockId:\"tacz:attachment_workbench\"}")),
                    new ShopOffer(new ShopItem("citylife:banknote_5000", 1, null), new ShopItem("tacz:workbench_b", 1, "{BlockId:\"elitex:elitebench\"}")),
                    new ShopOffer(new ShopItem("citylife:banknote_100", 8, null), new ShopItem("minecraft:iron_ingot", 16, null)),
                    new ShopOffer(new ShopItem("citylife:banknote_100", 16, null), new ShopItem("minecraft:gold_ingot", 8, null)),
                    new ShopOffer(new ShopItem("citylife:banknote_100", 5, null), new ShopItem("minecraft:copper_ingot", 16, null)),
                    new ShopOffer(new ShopItem("citylife:banknote_100", 4, null), new ShopItem("minecraft:gunpowder", 8, null)),
                    new ShopOffer(new ShopItem("citylife:banknote_100", 4, null), new ShopItem("minecraft:lapis_lazuli", 8, null)),
                    new ShopOffer(new ShopItem("citylife:banknote_100", 3, null), new ShopItem("minecraft:redstone", 16, null)),
                    new ShopOffer(new ShopItem("citylife:banknote_100", 4, null), new ShopItem("minecraft:leather", 8, null)),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 3, null), new ShopItem("minecraft:diamond", 2, null)),
                    new ShopOffer(new ShopItem("citylife:banknote_100", 2, null), new ShopItem("minecraft:oak_log", 16, null)),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 1, null), new ShopItem("minecraft:blaze_rod", 2, null)),
                    new ShopOffer(new ShopItem("citylife:banknote_100", 5, null), new ShopItem("minecraft:amethyst_shard", 8, null))))),
            Map.entry("medic", new Shop("Аптека", List.of(
                    new ShopOffer(new ShopItem("citylife:banknote_100", 1, null), new ShopItem("minecraft:golden_apple", 1, null)),
                    new ShopOffer(new ShopItem("citylife:coin_10", 8, null), new ShopItem("minecraft:potion", 1, null))))),
            Map.entry("phone_seller", new Shop("Салон связи", List.of(
                    new ShopOffer(new ShopItem("citylife:banknote_100", 3, null), new ShopItem("citylife:sim_card", 1, null)),
                    new ShopOffer(new ShopItem("citylife:banknote_100", 15, null), new ShopItem("citylife:phone_nokta", 1, null)),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 4, null), new ShopItem("citylife:phone_mini", 1, null)),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 6, null), new ShopItem("citylife:phone_gran_a5", 1, null)),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 9, null), new ShopItem("citylife:smartphone", 1, null)),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 12, null), new ShopItem("citylife:phone_polus", 1, null)),
                    new ShopOffer(new ShopItem("citylife:banknote_5000", 6, null), new ShopItem("citylife:phone_gran_x", 1, null)),
                    new ShopOffer(new ShopItem("citylife:banknote_5000", 8, null), new ShopItem("citylife:phone_fold", 1, null))))),
            Map.entry("realtor", new Shop("Агентство недвижимости", List.of(
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 1, null), new ShopItem("citylife:smart_lock", 1, null)),
                    new ShopOffer(new ShopItem("citylife:banknote_100", 2, null), new ShopItem("securitycraft:keypad", 1, null)),
                    new ShopOffer(new ShopItem("citylife:banknote_5000", 1, null), new ShopItem("securitycraft:security_camera", 2, null))))),
            Map.entry("rifle_dealer", new Shop("Винтовки и пулемёты", List.of(
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 22, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"elitex:ak47\",GunFireMode:\"AUTO\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 22, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"elitex:akx105\",GunFireMode:\"AUTO\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 22, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"elitex:famas_f1\",GunFireMode:\"AUTO\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 22, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"elitex:fh_scar18\",GunFireMode:\"SEMI\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 22, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"elitex:fs_scar19\",GunFireMode:\"AUTO\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 22, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"elitex:m16\",GunFireMode:\"BURST\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 22, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"elitex:m4_sopmod\",GunFireMode:\"AUTO\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 22, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"elitex:m4a1_classic\",GunFireMode:\"AUTO\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 22, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"elitex:mcs_spear\",GunFireMode:\"AUTO\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 22, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"elitex:sassy_dmr\",GunFireMode:\"SEMI\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 22, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"tacz:ak47\",GunFireMode:\"AUTO\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 22, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"tacz:aug\",GunFireMode:\"AUTO\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 22, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"tacz:fn_fal\",GunFireMode:\"SEMI\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 22, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"tacz:g36k\",GunFireMode:\"AUTO\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 22, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"tacz:hk416d\",GunFireMode:\"AUTO\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 22, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"tacz:hk_g3\",GunFireMode:\"SEMI\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 22, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"tacz:m16a1\",GunFireMode:\"AUTO\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 22, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"tacz:m16a4\",GunFireMode:\"BURST\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 22, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"tacz:m4a1\",GunFireMode:\"AUTO\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 22, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"tacz:mk14\",GunFireMode:\"SEMI\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 22, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"tacz:qbz_191\",GunFireMode:\"AUTO\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 22, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"tacz:qbz_95\",GunFireMode:\"AUTO\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 22, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"tacz:scar_h\",GunFireMode:\"SEMI\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 22, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"tacz:scar_l\",GunFireMode:\"AUTO\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 22, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"tacz:sks_tactical\",GunFireMode:\"SEMI\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 22, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"tacz:spr15hb\",GunFireMode:\"SEMI\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 22, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"tacz:type_81\",GunFireMode:\"AUTO\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_5000", 13, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"elitex:golden_ak\",GunFireMode:\"AUTO\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_5000", 7, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"elitex:inter_m200\",GunFireMode:\"SEMI\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_5000", 7, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"elitex:kar98k\",GunFireMode:\"SEMI\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_5000", 7, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"elitex:lee\",GunFireMode:\"SEMI\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_5000", 7, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"elitex:m1_garand\",GunFireMode:\"SEMI\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_5000", 7, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"elitex:sp_m1903\",GunFireMode:\"SEMI\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_5000", 7, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"tacz:ai_awp\",GunFireMode:\"SEMI\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_5000", 7, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"tacz:kar98\",GunFireMode:\"SEMI\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_5000", 7, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"tacz:m107\",GunFireMode:\"SEMI\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_5000", 7, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"tacz:m700\",GunFireMode:\"SEMI\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_5000", 7, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"tacz:m95\",GunFireMode:\"SEMI\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_5000", 7, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"tacz:springfield1873\",GunFireMode:\"SEMI\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_5000", 10, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"elitex:m249x\",GunFireMode:\"AUTO\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_5000", 10, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"tacz:fn_evolys\",GunFireMode:\"AUTO\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_5000", 10, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"tacz:m249\",GunFireMode:\"AUTO\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_5000", 10, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"tacz:minigun\",GunFireMode:\"AUTO\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_5000", 10, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"tacz:rpk\",GunFireMode:\"AUTO\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_5000", 16, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"tacz:m320\",GunFireMode:\"SEMI\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}")),
                    new ShopOffer(new ShopItem("citylife:banknote_5000", 16, null), new ShopItem("tacz:modern_kinetic_gun", 1, "{GunId:\"tacz:rpg7\",GunFireMode:\"SEMI\",GunCurrentAmmoCount:0,HasBulletInBarrel:0b}"))))),
            Map.entry("security", new Shop("Магазин", List.of(
))),
            Map.entry("shopkeeper", new Shop("Магазин", List.of(
                    new ShopOffer(new ShopItem("citylife:coin_10", 3, null), new ShopItem("minecraft:torch", 16, null)),
                    new ShopOffer(new ShopItem("citylife:coin_10", 5, null), new ShopItem("minecraft:oak_planks", 32, null)),
                    new ShopOffer(new ShopItem("citylife:banknote_100", 1, null), new ShopItem("minecraft:iron_pickaxe", 1, null)),
                    new ShopOffer(new ShopItem("citylife:coin_10", 2, null), new ShopItem("minecraft:bucket", 1, null))))),
            Map.entry("trader_clothes", new Shop("Одежда", List.of(
                    new ShopOffer(new ShopItem("citylife:banknote_100", 2, null), new ShopItem("minecraft:leather_chestplate", 1, null)),
                    new ShopOffer(new ShopItem("citylife:banknote_100", 1, null), new ShopItem("minecraft:leather_boots", 1, null)),
                    new ShopOffer(new ShopItem("citylife:coin_10", 8, null), new ShopItem("minecraft:white_dye", 8, null))))),
            Map.entry("trader_food", new Shop("Продукты", List.of(
                    new ShopOffer(new ShopItem("citylife:coin_10", 3, null), new ShopItem("minecraft:bread", 4, null)),
                    new ShopOffer(new ShopItem("citylife:coin_10", 6, null), new ShopItem("minecraft:cooked_beef", 3, null)),
                    new ShopOffer(new ShopItem("citylife:banknote_100", 1, null), new ShopItem("minecraft:golden_carrot", 4, null)),
                    new ShopOffer(new ShopItem("citylife:coin_10", 2, null), new ShopItem("minecraft:sweet_berries", 6, null))))),
            Map.entry("trader_tech", new Shop("Электроника", List.of(
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 18, null), new ShopItem("citylife:tablet", 1, null)),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 28, null), new ShopItem("citylife:laptop", 1, null)),
                    new ShopOffer(new ShopItem("citylife:banknote_5000", 1, null), new ShopItem("citylife:monitor", 1, null)),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 1, null), new ShopItem("citylife:keyboard", 1, null)),
                    new ShopOffer(new ShopItem("citylife:banknote_100", 6, null), new ShopItem("citylife:mouse", 1, null)),
                    new ShopOffer(new ShopItem("citylife:banknote_100", 25, null), new ShopItem("citylife:pc_case", 1, null)),
                    new ShopOffer(new ShopItem("citylife:banknote_1000", 2, null), new ShopItem("cameracraft:camera", 1, null)))))
    );

    /** Что говорят те, у кого нет прилавка. */
    public static final Map<String, List<String>> LINES = Map.ofEntries(
            Map.entry("cop", List.of("Порядок в городе — моя работа. Проезжай, не задерживайся.", "Оружие носи в кобуре. Увижу в руках — разговор будет другой.", "Потерял машину? Смотри на стоянке у мэрии, туда всё свозят.")),
            Map.entry("firefighter", List.of("Огонь в жилом квартале — сразу к нам, не тушите сами.", "Каска на голове, вода в баке. Живём.", "Без учений скучно, с учениями тяжело.")),
            Map.entry("security", List.of("Вход свободный, но за витрины отвечаешь ты.", "Сумки на входе не проверяем. Пока.", "Драку начнёшь — вынесу на улицу сам.")),
            Map.entry("state", List.of("Приём граждан по будням. Сегодня, считай, будни.", "Все бумаги — в мэрию, там и очередь короче."))
    );

    /** Реплика на случай роли без своего текста. */
    public static final List<String> DEFAULT_LINES = List.of("Добрый день. Хорошего дня в городе.");

    private ShopCatalog() {
    }
}
