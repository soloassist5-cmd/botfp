# Сервер для игры с друзьями через Radmin VPN

Radmin VPN делает вид, будто все компьютеры в одной локальной сети, поэтому
никакой проброс портов на роутере не нужен. Но брандмауэр Windows всё равно
надо настроить — именно на нём чаще всего и застревают и игра, и голосовой чат.

## Что нужно хосту

| Параметр | Значение |
|---|---|
| ОЗУ компьютера | 8 ГБ и больше (серверу отдаём 4 ГБ, остальное системе и своей игре) |
| Java | 17 |
| Комфортный онлайн | 2–8 человек |
| Порты | TCP/UDP **25565** (игра), UDP **24454** (голосовой чат) |

Хост может играть на том же компьютере: выделите серверу 4 ГБ, своему клиенту
4–6 ГБ. Если оперативки 8 ГБ — лучше играть на другом компьютере или снизить
прорисовку.

## 1. Установка сервера

```bash
# Linux / macOS
cd mcpack/install
./install.sh --target server --path ~/ls-city-server
```

```powershell
# Windows
cd mcpack\install
powershell -ExecutionPolicy Bypass -File .\install.ps1 -Target server -Path "C:\ls-city-server"
```

Установщик:

- поставит 47 серверных модов (клиентские — Embeddium, Xaero's, Distant
  Horizons и прочие — в серверный пак не попадут);
- скачает и развернёт серверный Forge 47.4.23;
- положит `start.sh` / `start.bat`, `server.properties` и конфиг голосового чата;
- распакует город в `world/`.

## 2. Прими EULA

Открой `eula.txt` и поменяй строку на:

```
eula=true
```

Это согласие с лицензией Minecraft. За тебя его никто поставить не может.

## 3. Проверь server.properties

В комплекте уже настроено то, что важно:

```properties
online-mode=false      # иначе друзья с пиратских лаунчеров не зайдут
white-list=true        # на online-mode=false это единственная защита
max-players=8
view-distance=8
simulation-distance=6
server-port=25565
server-ip=             # пусто = слушать все адреса, включая Radmin VPN
```

**Про `online-mode=false`:** лицензии игроков не проверяются, значит зайти может
любой, кто знает адрес. Поэтому включён белый список. После первого запуска
добавь друзей:

```
/whitelist add Ник
/whitelist reload
```

Ники при `online-mode=false` не защищены: кто угодно может назваться чужим
ником из белого списка. Не публикуй свой Radmin-адрес.

## 4. Запуск

```bash
RAM=4G ./start.sh      # Linux / macOS
```

```
start.bat              # Windows (память меняется строкой set RAM=4G внутри)
```

Первый запуск — 1–3 минуты: моды прогревают кэш. Готовность видна по строке
`Done (…)! For help, type "help"`. Остановка — команда `stop` в консоли, не
закрытие окна: иначе мир может не сохраниться.

## 5. Radmin VPN

1. Хост и друзья ставят [Radmin VPN](https://www.radmin-vpn.com/).
2. Хост: **Создать сеть** → задаёт имя и пароль, передаёт их друзьям.
3. Друзья: **Подключиться к сети** → вводят имя и пароль.
4. В окне Radmin VPN у хоста виден его адрес вида `26.x.x.x` — это и есть адрес
   сервера.
5. Друзья в Minecraft: **Сетевая игра → По адресу** →
   ```
   26.x.x.x:25565
   ```

Хост со своего же компьютера заходит по `localhost`.

## 6. Брандмауэр Windows (самое частое место сбоя)

Голос и подключение ломаются именно здесь. Открой PowerShell **от имени
администратора** и выполни:

```powershell
New-NetFirewallRule -DisplayName "Minecraft LS City TCP" -Direction Inbound -Protocol TCP -LocalPort 25565 -Action Allow
New-NetFirewallRule -DisplayName "Minecraft LS City UDP" -Direction Inbound -Protocol UDP -LocalPort 25565 -Action Allow
New-NetFirewallRule -DisplayName "Simple Voice Chat" -Direction Inbound -Protocol UDP -LocalPort 24454 -Action Allow
```

Ещё убедись, что сеть Radmin VPN в Windows считается **частной**, а не
общедоступной: в общедоступных сетях правила брандмауэра по умолчанию строже.

## 7. Голосовой чат

Конфиг уже лежит в `config/voicechat/voicechat-server.properties`:

```properties
port=24454
max_voice_distance=48
enable_groups=true
```

Проверка на клиенте: в игре клавиша `V` — настройки голосового чата. Если
написано, что соединение не установлено, почти всегда виноват UDP-порт 24454 в
брандмауэре хоста.

## 8. После первого запуска

Один раз расставь жителей города (команда в консоли сервера, без слэша):

```
function citylife:npc/spawn_all
```

Полезные команды:

| Команда | Что делает |
|---|---|
| `function citylife:npc/spawn_all` | Расставить NPC заново (старых уберёт) |
| `function citylife:npc/clear` | Убрать всех NPC города |
| `schedule clear citylife:city/mob_clean` | Вернуть мобов в черту города |
| `citylife money give Ник 500` | Начислить деньги на счёт |
| `whitelist add Ник` | Пустить игрока на сервер |

## 9. Бэкапы

Мир — это каталог `world/`. Останови сервер (`stop`) и скопируй его целиком.
Заодно копируй `world/data/citylife_city.dat`: в нём банковские счёта,
сообщения и привязки замков.

## Если не подключаются

| Симптом | Что проверить |
|---|---|
| «Не удалось подключиться к серверу» | Сервер дошёл до `Done`? Правильный ли адрес Radmin? Правило брандмауэра на 25565? |
| «You are not white-listed on this server» | `whitelist add Ник` и `whitelist reload` |
| Зашёл, но всех выкидывает через минуту | Мало памяти серверу: поставь `RAM=6G` |
| Голос не работает, игра работает | UDP 24454 в брандмауэре; сеть Radmin помечена как частная |
| Разные версии модов | У всех должна быть одна сборка: пусть каждый запустит установщик из этого репозитория |
